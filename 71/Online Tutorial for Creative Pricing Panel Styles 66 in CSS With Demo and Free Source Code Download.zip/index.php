<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">
    <title></title>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
<div class="col-md-12">
<h1 style="margin-top: 20px; text-align: center; color: #000;">Pricing Table Styles</h1>
</div>
        <div class="col-md-4 col-sm-6">
            <div class="pricingTable">
                <div class="pricingTable-header">
                    <h3 class="heading">STANDARD</h3>
                </div>
                <div class="price-Value">
                    <span class="amount">100
                        <span class="currency">$</span>
                    </span>
                </div>
                <a href="#" class="pricingTable-signup">SIGN IN</a>
            </div>
        </div>
 
        <div class="col-md-4 col-sm-6">
            <div class="pricingTable">
                <div class="pricingTable-header">
                    <h3 class="heading">Business</h3>
                </div>
                <div class="price-Value">
                    <span class="amount">200
                        <span class="currency">$</span>
                    </span>
                </div>
                <a href="#" class="pricingTable-signup">SIGN IN</a>
            </div>
        </div>
    </div>
    <div class="col-md-12">
<p style="margin-top: 20px; text-align: center;  color: #000;">wwww.websitedesignndevelopment.com</p>
</div>
</div>
</body>
</html>
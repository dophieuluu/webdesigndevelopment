<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
	<title></title>
</head>
<body>
<div class="container">
   <div class="row justify-content-center">
<div class="col-md-12">
<h1 style="margin-top: 20px; text-align: center; color: #000;">Progress Bar Styles</h1>
</div>
        <div class="col-sm-offset-2 col-sm-8">
            <div class="progress_bar_13">
                <div class="progress-bar-description">
                    HTML5
                    <span style="left:75%;">75%</span>
                </div>
                <div class="pro-bar">
                    <span class="progress-bar-outer already-animated" style="background-color: #19bc9b; width: 75%;" data-width="75">
                        <span class="progress-bar-inner"></span>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-offset-2 col-sm-7">
            <div class="progress_bar_13">
                <div class="progress-bar-description">
                    CSS3
                    <span style="left:65%;">65%</span>
                </div>
                <div class="pro-bar">
                    <span class="progress-bar-outer already-animated" style="background-color: #e67e22; width: 65%;" data-width="65">
                        <span class="progress-bar-inner"></span>
                    </span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
<p style="margin-top: 20px; text-align: center;  color: #000;">wwww.websitedesignndevelopment.com</p>
</div>
</div>
</body>
</html>
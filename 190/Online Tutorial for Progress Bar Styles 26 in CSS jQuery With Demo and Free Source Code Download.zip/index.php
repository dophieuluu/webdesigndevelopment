<!DOCTYPE html>
<html>
<head>
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
		<div class="col-md-12">
		<h1 style="margin-top: 30px; text-align: center; color:#000; ">Progress Bar Styles</h1>
		</div>
            <h3 class="progress-title">HTML5</h3>; 
            <div class="progress pink">
                <div class="progress-bar" style="width:90%; background:#ff4b7d;">
                    <div class="progress-value">90%</div>
                </div>
            </div>
 
            <h3 class="progress-title">CSS3</h3>
            <div class="progress green">
                <div class="progress-bar" style="width:75%; background:#5fad56;">
                    <div class="progress-value">75%</div>
                </div>
            </div>
        </div>
		<div class="col-md-12">
		<p style="margin-top: 30px; text-align: center; color:#000; ">www,websitedesignndevelopment.com</p>
		</div>
    </div>
</div>
</body>
</html>
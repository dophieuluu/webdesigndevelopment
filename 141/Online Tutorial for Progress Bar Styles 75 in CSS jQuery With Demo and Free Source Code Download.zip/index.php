<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
	<title></title>
</head>
<body>
<div class="container">
   <div class="row justify-content-center">
<div class="col-md-12">
<h1 style="margin-top: 20px; text-align: center; color: #000;">Progress Bar Styles</h1>
</div>
        <div class="col-sm-6">
            <input type="radio" class="radio" name="progress" value="five" id="five1">
            <label for="five" class="label">5%</label>
 
            <input type="radio" class="radio" name="progress" value="twentyfive" id="twentyfive1">
            <label for="twentyfive" class="label">25%</label>
 
            <input type="radio" class="radio" name="progress" value="fifty" id="fifty1">
            <label for="fifty" class="label">50%</label>
 
            <input type="radio" class="radio" name="progress" value="seventyfive" id="seventyfive1">
            <label for="seventyfive" class="label">75%</label>
 
            <input type="radio" class="radio" name="progress" value="onehundred" id="onehundred1">
            <label for="onehundred" class="label">100%</label>
 
            <div class="progress-5">
                <div class="progress-bar-5"></div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
<p style="margin-top: 20px; text-align: center;  color: #000;">wwww.websitedesignndevelopment.com</p>
</div>
</div>
</body>
</html>